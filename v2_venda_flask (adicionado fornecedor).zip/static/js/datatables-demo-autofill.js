$(document).ready(function() {
    $('#dataTable').DataTable( {
        autoFill: true
    } );
} );
