$(document).ready(function() {
    $('#dataTable').DataTable( {
        autoFill: true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Portuguese-Brasil.json"
        }
    } );
} );
